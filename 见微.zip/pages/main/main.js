// pages/main/main.js
Page({

        getCode: function(){    
            
          var _this = this;
          wx.scanCode({        //扫描API
            success: function(res){
              // const selectData = JSON.stringify(this.data.selectData);
               let sendid=res.result;  
              _this.setData({
                qRCodeMsg: res.result,   //将这个结果res.result传回后台进行匹配数据输出结果
              });
              // console.log("result:"+res.result);
              console.log("result is:"+sendid);
              wx.showToast({
                title: '成功',
                duration: 2000
              });
              wx.navigateTo({
                url: '../scan/scan?id='+sendid
                // url: '../scan/scan?id=${qRCodeMsg}',
              })
            }, 
            fail: (res) => {
              console.log(res);
              wx.showToast({
                title: '失败',
                icon:'error',
                duration: 2000
              })
            },   
          })
        },
        price:function(){
          wx.navigateTo({
              url: '../price/price',
          })
            },
            search2btn:function(){
              wx.navigateTo({
                  url: '../search2/search2',
              })
                },
                knowledgebtn:function(){
                  wx.navigateTo({
                      url: '../knowledge/knowledge',
                  })
                    },
                    searchresult:function(){
                      console.log(11111);
                    },
                     input1:function(e){
                      console.log(e);
                      // console.log(e.detail.value.input1)
                     },
                    //  input2input:function(e){
                    //    console.log(e);
                    //    console.log(e.detail.value.input2);
                    //    this.setData({ input2:e.detail.value.input2})
                    //  },
  data:{
    qRCodeMsg:'',
    show:"",
    addName: "",
    input1:"",
    input2:"test input2",
  },
   
    /**扫码 */

 
})